#!/bin/sh

python3 Assignment05.py