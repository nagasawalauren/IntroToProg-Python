#writefile.py
#Lauren Nagasawa
#04-30-2017
#This program records values entered for name and estimated value input by the user.

def writefile():
    yn1 = 'y'

    myname = input("Enter Name of Home: ") + "\n"
    tup1 = (myname,)
    myvalue = input("Enter Estimated Value: ") + "\n"    
    
    tup1 += tuple([myvalue]) 
    
    print("\nYOUR OUTPUT\n\nName of Property: " + tup1[0] + "\n" + "Estimated Value: " + tup1[1] + "\n")
    yn1 = input("Write To File? y/n: ")
    if (yn1 == 'y'):
        objFile = open("HomeInventory.txt","a")
        for t in tup1:
            line = ''.join(str(x) for x in t)
            objFile.write(line)
        objFile.write("\n")
        objFile.close()

def main():
    yn = 'y'
    
    while(yn != 'n'):
        writefile()
        yn = input("Enter y/n to write another value: ")
    
    
main()