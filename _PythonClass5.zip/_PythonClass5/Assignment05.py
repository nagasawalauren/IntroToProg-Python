#-------------------------------------------------#
# Title: Working with Dictionaries (Assignment 5)
# Dev:   Lauren Nagasawa
# Date:  05-07-2017

#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------

objFileName = "Todo.txt"
strData = ""
dicRow = {}

lstTable = []

# Step 1
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary.

def showDict():
        taskval = 1
        for keys,values in dicRow.items():
            print("Task ", taskval, ": ")
            print("Name: ", keys)
            print("Priority: ", values)
            print("\n")
            taskval+=1
            
def showList():
        valx = 0
        while valx < len(lstTable):
            print("Task ", valx+1, ": ")
            print(lstTable[valx])
            valx += 1
            
def fileOpenRead():
    #only open file, write to dictionary and to list.
        o = open(objFileName,"r")

        for line in o:
            print(line)
            dicRow = {}
            (key,val) = line.split(',',1)
            dicRow[str(key)] = val
            print(dicRow)
            lstTable.append(dicRow)
        o.close()
        showList()
    

# Step 2 - Display a menu of choices to the user
def printMenu():
        print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    
def addSessionEntry():

    yn = "y"
    saveyn = "y"
    
    while (yn == "y"): 
        priority = ""
        taskname = ""
        taskname += input("\nEnter Task Name: ").lower()
        priority = input("\nEnter Priority ('high', 'low', 'medium'): ").lower()
        
        
        print("Task: ",taskname,'\n', "Priority: ", priority, "\n\n")
        saveyn = input("\nSave to List? (y/n): ")
        
        if (saveyn == 'y'):
            lstTable.append({taskname:priority})
        
        yn = input("\nAdd Another Entry? (y/n): ")

def removeSessionEntry():
    rmvIndex = ""
    confirmrmv = "y"
    repeat = "y"
    

    
    while(repeat == "y"):
        showList()
        rmvIndex = int(input("\nEnter Number of Task to Remove: ")) - 1
        print("Row: ",lstTable[rmvIndex], "\n\n")
        confirmrmv = input("Remove from Dictionary? (y/n): ")
        if(confirmrmv == "y"):
            del lstTable[rmvIndex]
            showList()
        repeat = input("Remove another? (y/n): ")
        
def writeToFile():
        confirm = "y"
        textfile = ""
        
        showList()

        confirm = input("Are you sure you want to write to file? It will overwrite the old file. (y/n): ")
        
        if(confirm == 'y'):
            myFile = open(objFileName, "w")
            myFile.truncate()
            
            i = 0
            while i < len(lstTable):
                for keys,values in lstTable[i].items():
                    line = keys + "," + values
                    line = line.replace('\n', '')
                    line += '\n'
                    textfile += line
                i += 1
                
            myFile.write(textfile)
                 
        print("\nYour To Do List Has Been Updated. \n\n")
        myFile.close()
        
def main():
    fileOpenRead()  
    print("FILE READ.\n")
    while(True):
      
        printMenu()
    
        strChoice = str(input("\nWhich option would you like to perform? [1 to 5] : "))
    
        print()#adding a new line
    


    # Step 3 -Show the current items in the table
        if (strChoice.strip() == '1'):
            showList()
            continue
        
    # Step 4 - Add a new item to the list/Table
        elif(strChoice.strip() == '2'):
            addSessionEntry()
            continue
        
    # Step 5 - Remove a new item to the list/Table
        elif(strChoice == '3'):
            removeSessionEntry()
            continue
        
    # Step 6 - Save tasks to the ToDo.txt file
        elif(strChoice == '4'):
            writeToFile()
            continue
        
        elif (strChoice == '5'):
            break #and Exit the program
        
main()