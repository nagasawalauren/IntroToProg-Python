#!/bin/sh

python3 Assignment06.py