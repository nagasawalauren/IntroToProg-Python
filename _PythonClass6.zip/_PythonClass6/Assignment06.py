#-------------------------------------------------#
# Title: Working with Dictionaries (Assignment 6)
# Dev:   Lauren Nagasawa
# Date:  05-15-2017


#objFileName = "Todo.txt"
#strData = ""
#dicRow = {}

#lstTable = []

# Step 1
    # When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
objFileName = "Todo.txt"
strData = ""
dicRow = {}
lstTable = []
    
class ToDoList(object):


    @staticmethod
    def fileOpenRead():
        #only open file, write to dictionary and to list.
            o = open(objFileName,"r")

            for line in o:
                print(line)
                dicRow = {}
                (key,val) = line.split(',',1)
                dicRow[str(key)] = val
                print(dicRow)
                lstTable.append(dicRow)
            o.close()
            ToDoList.showList()
    
    @staticmethod
    def showList():
            valx = 0
            while valx < len(lstTable):
                print("Task ", valx+1, ": ")
                print(lstTable[valx])
                valx += 1


    @staticmethod
    def addSessionEntry():

        yn = "y"
        saveyn = "y"

        while (yn == "y"): 
            priority = ""
            taskname = ""
            taskname += input("\nEnter Task Name: ").lower()
            priority = input("\nEnter Priority ('high', 'low', 'medium'): ").lower()


            print("Task: ",taskname,'\n', "Priority: ", priority, "\n\n")
            saveyn = input("\nSave to List? (y/n): ")

            if (saveyn == 'y'):
                lstTable.append({taskname:priority})

            yn = input("\nAdd Another Entry? (y/n): ")
    @staticmethod
    def removeSessionEntry():
        rmvIndex = ""
        confirmrmv = "y"
        repeat = "y"



        while(repeat == "y"):
            ToDoList.showList()
            rmvIndex = int(input("\nEnter Number of Task to Remove: ")) - 1
            print("Row: ",lstTable[rmvIndex], "\n\n")
            confirmrmv = input("Remove from Dictionary? (y/n): ")
            if(confirmrmv == "y"):
                del lstTable[rmvIndex]
                ToDoList.showList()
            repeat = input("Remove another? (y/n): ")
    @staticmethod
    def writeToFile():
            confirm = "y"
            textfile = ""

            ToDoList.showList()

            confirm = input("Are you sure you want to write to file? It will overwrite the old file. (y/n): ")

            if(confirm == 'y'):
                myFile = open(objFileName, "w")
                myFile.truncate()

                i = 0
                while i < len(lstTable):
                    for keys,values in lstTable[i].items():
                        line = keys + "," + values
                        line = line.replace('\n', '')
                        line += '\n'
                        textfile += line
                    i += 1

                myFile.write(textfile)

                print("\nYour To Do List Has Been Updated. \n\n")
                myFile.close()


############################################

def printMenu():
        print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
        
def main():
    
    myToDoList = ToDoList()
    myToDoList.fileOpenRead()
        
    while(True):


        printMenu()
        strChoice = str(input("\nWhich option would you like to perform? [1 to 5] : "))
            # Step 3 -Show the current items in the table
        if (strChoice.strip() == '1'):
            myToDoList.showList()
            continue
        
    # Step 4 - Add a new item to the list/Table
        elif(strChoice.strip() == '2'):
            myToDoList.addSessionEntry()
            continue
        
    # Step 5 - Remove a new item to the list/Table
        elif(strChoice == '3'):
            myToDoList.removeSessionEntry()
            continue
        
    # Step 6 - Save tasks to the ToDo.txt file
        elif(strChoice == '4'):
            myToDoList.writeToFile()
            continue
        
        elif (strChoice == '5'):
            myToDoList.writeToFile()
            break #and Exit the program
    
main()